export const GET_GROUP = "GET_GROUP";
export const GET_GROUP_SUCCESS = "GET_GROUP_SUCCESS";
export const GET_GROUP_ERROR = "GET_GROUP_ERROR";

export const SET_GROUP = "SET_GOUP";
